package com.vendingmachine.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vendingmachine.enums.Coin;
import com.vendingmachine.service.VendingMachine;

@RestController
@RequestMapping(value = "/vendingmachine", produces = MediaType.APPLICATION_JSON_VALUE)
public class VendingMachineController {

	@Autowired
	VendingMachine vendingMachine;

	@PostMapping(value = "/insertCoin", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String insertCoin(@RequestBody Coin coin) {
		vendingMachine.insertCoin(coin);
		return "success";
	}
}
