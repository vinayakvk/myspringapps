package com.vendingmachine.factory;

import com.vendingmachine.service.VendingMachine;
import com.vendingmachine.serviceimpl.VendingMachineImpl;

public class VendingMachineFactory {
	public static VendingMachine createVendingMachine() {
		return new VendingMachineImpl();
	}
}
