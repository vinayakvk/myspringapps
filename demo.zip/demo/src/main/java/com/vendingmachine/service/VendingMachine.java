package com.vendingmachine.service;

import java.util.List;

import com.vendingmachine.entities.Bucket;
import com.vendingmachine.enums.Coin;
import com.vendingmachine.enums.Item;

public interface VendingMachine {
	public long selectItemAndGetPrice(Item item);

	public void insertCoin(Coin coin);

	public List<Coin> refund();

	public Bucket<Item, List<Coin>> collectItemAndChange();

	public void reset();
}
