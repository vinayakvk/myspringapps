package com.vendingMachine.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.vendingmachine.entities.Bucket;
import com.vendingmachine.enums.Coin;
import com.vendingmachine.enums.Item;
import com.vendingmachine.factory.VendingMachineFactory;
import com.vendingmachine.service.VendingMachine;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

	private static VendingMachine vm;

	@Test
	public void testBuyItemWithExactPrice() {
		vm = VendingMachineFactory.createVendingMachine();
		long price = vm.selectItemAndGetPrice(Item.COKE);
		assertEquals(Item.COKE.getPrice(), price);
		Bucket<Item, List<Coin>> bucket = vm.collectItemAndChange();
		Item item = bucket.getFirst();
		List<Coin> change = bucket.getSecond();
		assertEquals(Item.COKE, item);
		assertTrue(change.isEmpty());
	}

}
